import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, BookOpen, Clock, Award, Users } from 'lucide-react';
import SearchBar from '../components/SearchBar';
import CourseCard from '../components/CourseCard';
import CategoryCard from '../components/CategoryCard';
import Button from '../components/Button';
import { useCourses } from '../context/CourseContext';

const HomePage: React.FC = () => {
  const { featuredCourses, popularCourses, categories } = useCourses();
  
  // Scroll to top on component mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  
  const handleSearch = (query: string) => {
    // Navigate to courses page with search query
    window.location.href = `/courses?search=${encodeURIComponent(query)}`;
  };
  
  return (
    <div className="pt-16 bg-gray-50">
      {/* Hero section */}
      <section className="relative bg-gradient-to-r from-blue-600 to-purple-600 text-white py-20 md:py-28">
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute right-0 top-0 w-1/2 h-full bg-white opacity-10 transform -skew-x-12"></div>
          <div className="absolute left-0 bottom-0 w-1/3 h-1/2 bg-white opacity-10 transform skew-x-12"></div>
        </div>
        
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              Unlock Your Potential With Online Learning
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-blue-100">
              Discover high-quality courses taught by industry experts and transform your skills today.
            </p>
            <div className="max-w-md mb-8">
              <SearchBar onSearch={handleSearch} placeholder="What do you want to learn today?" />
            </div>
            <div className="flex flex-wrap gap-4">
              <Link to="/courses">
                <Button variant="primary" size="lg">
                  Explore Courses
                </Button>
              </Link>
              <Link to="/signup">
                <Button variant="outline" size="lg" className="bg-white bg-opacity-20 border-white text-white hover:bg-opacity-30">
                  Sign Up Free
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      {/* Stats section */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div className="p-6">
              <div className="text-blue-600 mb-2">
                <BookOpen className="h-8 w-8 mx-auto" />
              </div>
              <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">150+</h3>
              <p className="text-gray-600">Quality Courses</p>
            </div>
            <div className="p-6">
              <div className="text-blue-600 mb-2">
                <Users className="h-8 w-8 mx-auto" />
              </div>
              <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">50K+</h3>
              <p className="text-gray-600">Happy Students</p>
            </div>
            <div className="p-6">
              <div className="text-blue-600 mb-2">
                <Award className="h-8 w-8 mx-auto" />
              </div>
              <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">100+</h3>
              <p className="text-gray-600">Expert Instructors</p>
            </div>
            <div className="p-6">
              <div className="text-blue-600 mb-2">
                <Clock className="h-8 w-8 mx-auto" />
              </div>
              <h3 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">24/7</h3>
              <p className="text-gray-600">Learning Access</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Categories section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="mb-12 text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Browse Top Categories
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Explore our most popular course categories and find the perfect fit for your learning journey.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {categories.slice(0, 8).map(category => (
              <CategoryCard key={category.id} category={category} />
            ))}
          </div>
          
          <div className="mt-12 text-center">
            <Link to="/courses">
              <Button variant="outline">
                View All Categories <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
      
      {/* Featured courses section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex justify-between items-center mb-12">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Featured Courses
              </h2>
              <p className="text-gray-600 max-w-2xl">
                Handpicked courses to get you started on your learning journey.
              </p>
            </div>
            <Link to="/courses" className="hidden md:block">
              <Button variant="outline">
                View All Courses <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredCourses.map(course => (
              <CourseCard key={course.id} course={course} />
            ))}
          </div>
          
          <div className="mt-12 text-center md:hidden">
            <Link to="/courses">
              <Button variant="outline">
                View All Courses <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
      
      {/* Popular courses section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex justify-between items-center mb-12">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Most Popular Courses
              </h2>
              <p className="text-gray-600 max-w-2xl">
                Join thousands of students already learning with these top-rated courses.
              </p>
            </div>
            <Link to="/courses" className="hidden md:block">
              <Button variant="outline">
                View All Courses <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {popularCourses.map(course => (
              <CourseCard key={course.id} course={course} />
            ))}
          </div>
          
          <div className="mt-12 text-center md:hidden">
            <Link to="/courses">
              <Button variant="outline">
                View All Courses <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </Link>
          </div>
        </div>
      </section>
      
      {/* Call to action */}
      <section className="py-20 bg-gradient-to-r from-purple-600 to-blue-600 text-white">
        <div className="container mx-auto px-4 md:px-6 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Start Your Learning Journey?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Join thousands of students already learning on our platform. Gain in-demand skills and advance your career.
          </p>
          <div className="flex justify-center gap-4">
            <Link to="/signup">
              <Button 
                variant="primary" 
                size="lg" 
                className="bg-white text-blue-600 hover:bg-gray-100"
              >
                Sign Up For Free
              </Button>
            </Link>
            <Link to="/courses">
              <Button 
                variant="outline" 
                size="lg" 
                className="border-white text-white hover:bg-white hover:bg-opacity-10"
              >
                Browse Courses
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;