import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { 
  ChevronLeft, 
  ChevronRight, 
  List, 
  CheckCircle, 
  Circle, 
  X,
  BookOpen,
  PlayCircle
} from 'lucide-react';
import Button from '../components/Button';
import ProgressBar from '../components/ProgressBar';
import { useCourses } from '../context/CourseContext';
import { useAuth } from '../context/AuthContext';

const LessonViewer: React.FC = () => {
  const { courseId, lessonId } = useParams();
  const navigate = useNavigate();
  const { getCourse, markLessonComplete } = useCourses();
  const { isAuthenticated } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  
  // Get course details
  const course = getCourse(courseId || '');
  
  // Get current lesson
  const currentLesson = course?.lessons.find(lesson => lesson.id === lessonId);
  
  // Get current lesson index
  const currentLessonIndex = course?.lessons.findIndex(lesson => lesson.id === lessonId) ?? 0;
  
  // Previous and next lessons
  const prevLesson = currentLessonIndex > 0 ? course?.lessons[currentLessonIndex - 1] : null;
  const nextLesson = currentLessonIndex < (course?.lessons.length ?? 0) - 1 
    ? course?.lessons[currentLessonIndex + 1] 
    : null;
  
  // Scroll to top on component mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [lessonId]);
  
  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login', { state: { redirectTo: `/courses/${courseId}` } });
    }
  }, [isAuthenticated, navigate, courseId]);
  
  // Redirect if course or lesson not found
  useEffect(() => {
    if (!course || !currentLesson) {
      navigate('/dashboard');
    }
  }, [course, currentLesson, navigate]);
  
  if (!isAuthenticated || !course || !currentLesson) {
    return null; // Don't render anything while redirecting
  }
  
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };
  
  const markComplete = () => {
    if (lessonId) {
      markLessonComplete(courseId || '', lessonId);
    }
  };
  
  const goToNextLesson = () => {
    if (nextLesson) {
      navigate(`/courses/${courseId}/lessons/${nextLesson.id}`);
    } else {
      // If no next lesson, go to course completion or back to course detail
      navigate(`/courses/${courseId}`);
    }
  };
  
  const goToPrevLesson = () => {
    if (prevLesson) {
      navigate(`/courses/${courseId}/lessons/${prevLesson.id}`);
    }
  };
  
  const goToLesson = (lessonId: string) => {
    navigate(`/courses/${courseId}/lessons/${lessonId}`);
    setSidebarOpen(false);
  };
  
  return (
    <div className="flex h-screen bg-gray-100">
      {/* Sidebar */}
      <div 
        className={`fixed lg:relative z-40 w-80 bg-white h-full transform transition-transform duration-300 ease-in-out ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        } shadow-lg lg:shadow-none`}
      >
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between p-4 border-b">
            <Link to={`/courses/${courseId}`} className="flex items-center">
              <BookOpen className="h-5 w-5 text-blue-600 mr-2" />
              <span className="font-semibold text-gray-900 truncate">
                {course.title}
              </span>
            </Link>
            <button onClick={toggleSidebar} className="lg:hidden text-gray-500">
              <X className="h-5 w-5" />
            </button>
          </div>
          
          <div className="p-4 border-b">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-gray-600">Your Progress</span>
              <span className="text-sm font-medium">{course.progress}%</span>
            </div>
            <ProgressBar progress={course.progress || 0} height={6} />
          </div>
          
          <div className="flex-grow overflow-y-auto">
            <div className="p-4">
              <h3 className="font-medium text-gray-900 mb-4">Course Content</h3>
              <ul className="space-y-2">
                {course.lessons.map((lesson, index) => (
                  <li 
                    key={lesson.id}
                    className={`${lesson.id === currentLesson.id ? 'bg-blue-50 text-blue-700' : ''} rounded-md`}
                  >
                    <button
                      onClick={() => goToLesson(lesson.id)}
                      className="flex items-center w-full p-3 hover:bg-gray-50 rounded-md text-left"
                    >
                      <div className="mr-3">
                        {lesson.completed ? (
                          <CheckCircle className="h-5 w-5 text-green-500" />
                        ) : lesson.id === currentLesson.id ? (
                          <PlayCircle className="h-5 w-5 text-blue-600" />
                        ) : (
                          <Circle className="h-5 w-5 text-gray-300" />
                        )}
                      </div>
                      <div className="flex-grow">
                        <div className="flex items-center justify-between">
                          <span className={`text-sm ${lesson.id === currentLesson.id ? 'font-medium' : ''}`}>
                            {index + 1}. {lesson.title}
                          </span>
                          <span className="text-xs text-gray-500">{lesson.duration}</span>
                        </div>
                      </div>
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
      
      {/* Main content */}
      <div className="flex-grow overflow-y-auto">
        <div className="flex justify-between items-center bg-white p-4 shadow-sm">
          <button 
            onClick={toggleSidebar}
            className="flex items-center lg:hidden"
          >
            <List className="h-5 w-5 text-gray-700 mr-2" />
            <span className="text-gray-700">Contents</span>
          </button>
          <div className="text-gray-700 text-sm hidden md:block">
            Lesson {currentLessonIndex + 1} of {course.lessons.length}
          </div>
          <div className="flex items-center space-x-2">
            <Button 
              variant="outline" 
              onClick={goToPrevLesson}
              disabled={!prevLesson}
              className="flex items-center"
            >
              <ChevronLeft className="h-4 w-4 mr-1" />
              <span className="hidden md:inline">Previous</span>
            </Button>
            <Button 
              variant="outline" 
              onClick={goToNextLesson}
              className="flex items-center"
            >
              <span className="hidden md:inline">Next</span>
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </div>
        
        <div className="max-w-4xl mx-auto px-4 py-8">
          <h1 className="text-2xl font-bold text-gray-900 mb-6">
            {currentLessonIndex + 1}. {currentLesson.title}
          </h1>
          
          {/* Video player */}
          <div className="bg-black aspect-video rounded-lg shadow-lg mb-8 flex items-center justify-center">
            {currentLesson.videoUrl ? (
              <iframe 
                src={currentLesson.videoUrl} 
                title={currentLesson.title}
                className="w-full h-full"
                allowFullScreen
              ></iframe>
            ) : (
              <div className="text-center text-white">
                <PlayCircle className="h-16 w-16 text-white/50 mx-auto mb-4" />
                <p>Video placeholder for {currentLesson.title}</p>
              </div>
            )}
          </div>
          
          {/* Lesson content */}
          <div className="bg-white rounded-lg shadow-md p-6 mb-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Lesson Content</h2>
            <div className="prose max-w-none">
              <p>
                This is the detailed content for "{currentLesson.title}". In a real application, 
                this would include rich text, images, code samples, and other educational content.
              </p>
              <p className="mt-4">
                Key points covered in this lesson:
              </p>
              <ul className="mt-2">
                <li>Understanding the core concepts</li>
                <li>How to implement the techniques</li>
                <li>Best practices and common pitfalls</li>
                <li>Practical examples and use cases</li>
                <li>Additional resources and references</li>
              </ul>
            </div>
          </div>
          
          {/* Completion and navigation buttons */}
          <div className="flex flex-col sm:flex-row justify-between items-center bg-white rounded-lg shadow-md p-6">
            <div className="mb-4 sm:mb-0">
              {currentLesson.completed ? (
                <div className="flex items-center text-green-600">
                  <CheckCircle className="h-5 w-5 mr-2" />
                  <span>Lesson completed</span>
                </div>
              ) : (
                <Button 
                  variant="primary" 
                  onClick={markComplete}
                  className="bg-green-600 hover:bg-green-700"
                >
                  Mark as Complete
                </Button>
              )}
            </div>
            <div className="flex space-x-4">
              {prevLesson && (
                <Button 
                  variant="outline" 
                  onClick={goToPrevLesson}
                  className="flex items-center"
                >
                  <ChevronLeft className="h-4 w-4 mr-1" />
                  Previous Lesson
                </Button>
              )}
              {nextLesson ? (
                <Button 
                  variant="primary" 
                  onClick={goToNextLesson}
                  className="flex items-center"
                >
                  Next Lesson
                  <ChevronRight className="h-4 w-4 ml-1" />
                </Button>
              ) : (
                <Link to={`/courses/${courseId}`}>
                  <Button variant="primary">
                    Complete Course
                  </Button>
                </Link>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* Sidebar overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden"
          onClick={toggleSidebar}
        ></div>
      )}
    </div>
  );
};

export default LessonViewer;