import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  BookOpen, 
  Bookmark, 
  Settings, 
  Bell, 
  Award, 
  BarChart, 
  Clock,
  Play,
  ChevronRight
} from 'lucide-react';
import CourseCard from '../components/CourseCard';
import ProgressBar from '../components/ProgressBar';
import Button from '../components/Button';
import { useCourses } from '../context/CourseContext';
import { useAuth } from '../context/AuthContext';

const Dashboard: React.FC = () => {
  const { user, isAuthenticated } = useAuth();
  const { myCourses, popularCourses } = useCourses();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('my-courses');
  
  // Scroll to top on component mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  
  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login', { state: { redirectTo: '/dashboard' } });
    }
  }, [isAuthenticated, navigate]);
  
  if (!isAuthenticated || !user) {
    return null; // Don't render anything while redirecting
  }
  
  const inProgressCourses = myCourses.filter(course => course.progress && course.progress < 100);
  const completedCourses = myCourses.filter(course => course.progress === 100);
  
  const getOverallProgress = () => {
    if (myCourses.length === 0) return 0;
    const totalProgress = myCourses.reduce((sum, course) => sum + (course.progress || 0), 0);
    return Math.round(totalProgress / myCourses.length);
  };
  
  const renderTabContent = () => {
    switch (activeTab) {
      case 'my-courses':
        return (
          <div>
            {myCourses.length > 0 ? (
              <>
                {inProgressCourses.length > 0 && (
                  <div className="mb-12">
                    <h3 className="text-xl font-semibold text-gray-900 mb-6">Continue Learning</h3>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      {inProgressCourses.map(course => (
                        <CourseCard key={course.id} course={course} variant="compact" />
                      ))}
                    </div>
                  </div>
                )}
                
                {completedCourses.length > 0 && (
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-6">Completed Courses</h3>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      {completedCourses.map(course => (
                        <CourseCard key={course.id} course={course} variant="compact" />
                      ))}
                    </div>
                  </div>
                )}
              </>
            ) : (
              <div className="bg-white rounded-lg shadow-md p-8 text-center">
                <BookOpen className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No Courses Yet</h3>
                <p className="text-gray-600 mb-6">
                  You haven't enrolled in any courses yet. Explore our catalog to start learning.
                </p>
                <Link to="/courses">
                  <Button variant="primary">Browse Courses</Button>
                </Link>
              </div>
            )}
          </div>
        );
        
      case 'bookmarks':
        return (
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <Bookmark className="h-12 w-12 text-blue-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No Bookmarks Yet</h3>
            <p className="text-gray-600 mb-6">
              You haven't bookmarked any courses or lessons yet.
            </p>
          </div>
        );
        
      case 'settings':
        return (
          <div className="bg-white rounded-lg shadow-md p-8">
            <h3 className="text-xl font-semibold text-gray-900 mb-6">Account Settings</h3>
            <div className="max-w-md">
              <div className="mb-6">
                <label className="block text-gray-700 font-medium mb-2">Full Name</label>
                <input 
                  type="text" 
                  defaultValue={user.name}
                  className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:border-blue-500"
                />
              </div>
              <div className="mb-6">
                <label className="block text-gray-700 font-medium mb-2">Email Address</label>
                <input 
                  type="email" 
                  defaultValue={user.email}
                  className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:border-blue-500"
                />
              </div>
              <div className="mb-6">
                <label className="block text-gray-700 font-medium mb-2">Password</label>
                <input 
                  type="password" 
                  value="••••••••"
                  className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:border-blue-500"
                />
              </div>
              <Button variant="primary">Save Changes</Button>
            </div>
          </div>
        );
        
      default:
        return null;
    }
  };
  
  return (
    <div className="pt-16 min-h-screen bg-gray-50">
      {/* Header */}
      <section className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-12">
        <div className="container mx-auto px-4 md:px-6">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
            <div>
              <h1 className="text-3xl font-bold mb-2">Welcome back, {user.name.split(' ')[0]}!</h1>
              <p className="text-blue-100">
                {myCourses.length > 0 
                  ? `You've completed ${getOverallProgress()}% of your enrolled courses.` 
                  : 'Start your learning journey today.'}
              </p>
            </div>
            <div className="mt-4 md:mt-0">
              <Link to="/courses">
                <Button 
                  variant="outline" 
                  className="border-white text-white hover:bg-white hover:bg-opacity-10"
                >
                  Browse Courses
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>
      
      <div className="container mx-auto px-4 md:px-6 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Stats cards */}
          <div className="bg-white rounded-lg shadow-md p-6 flex items-center">
            <div className="bg-blue-100 p-3 rounded-full mr-4">
              <BookOpen className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <p className="text-gray-500 text-sm">Enrolled Courses</p>
              <p className="text-2xl font-bold text-gray-900">{myCourses.length}</p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6 flex items-center">
            <div className="bg-purple-100 p-3 rounded-full mr-4">
              <Clock className="h-6 w-6 text-purple-600" />
            </div>
            <div>
              <p className="text-gray-500 text-sm">Hours Learned</p>
              <p className="text-2xl font-bold text-gray-900">24</p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6 flex items-center">
            <div className="bg-green-100 p-3 rounded-full mr-4">
              <Award className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <p className="text-gray-500 text-sm">Certificates</p>
              <p className="text-2xl font-bold text-gray-900">{completedCourses.length}</p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6 flex items-center">
            <div className="bg-yellow-100 p-3 rounded-full mr-4">
              <BarChart className="h-6 w-6 text-yellow-600" />
            </div>
            <div>
              <p className="text-gray-500 text-sm">Overall Progress</p>
              <p className="text-2xl font-bold text-gray-900">{getOverallProgress()}%</p>
            </div>
          </div>
        </div>
        
        {/* Continue Learning section for active course */}
        {inProgressCourses.length > 0 && (
          <div className="mt-12 bg-white rounded-lg shadow-md p-6 lg:p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Continue Learning</h2>
            <div className="flex flex-col lg:flex-row">
              <div className="lg:w-1/3 relative mb-6 lg:mb-0 lg:mr-8">
                <img 
                  src={inProgressCourses[0].thumbnail} 
                  alt={inProgressCourses[0].title}
                  className="w-full h-48 lg:h-full object-cover rounded-lg"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Link to={`/courses/${inProgressCourses[0].id}/lessons/lesson-${inProgressCourses[0].id}-1`}>
                    <div className="bg-blue-600 p-4 rounded-full hover:bg-blue-700 transition-colors">
                      <Play className="h-8 w-8 text-white" />
                    </div>
                  </Link>
                </div>
              </div>
              <div className="lg:w-2/3">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {inProgressCourses[0].title}
                </h3>
                <p className="text-gray-600 mb-4">{inProgressCourses[0].instructor.name}</p>
                <div className="mb-4">
                  <ProgressBar 
                    progress={inProgressCourses[0].progress || 0} 
                    height={8}
                  />
                  <div className="flex justify-between mt-2 text-sm">
                    <span className="text-gray-600">{inProgressCourses[0].progress}% complete</span>
                    <span className="text-gray-600">
                      {Math.round((inProgressCourses[0].lessons.filter(l => l.completed).length / 
                        inProgressCourses[0].lessons.length) * inProgressCourses[0].lessons.length)} / {inProgressCourses[0].lessons.length} lessons
                    </span>
                  </div>
                </div>
                <div className="mt-6">
                  <Link to={`/courses/${inProgressCourses[0].id}/lessons/lesson-${inProgressCourses[0].id}-1`}>
                    <Button variant="primary">
                      Continue Learning
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {/* Dashboard tabs */}
        <div className="mt-12">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8">
              <button
                onClick={() => setActiveTab('my-courses')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'my-courses'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                My Courses
              </button>
              <button
                onClick={() => setActiveTab('bookmarks')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'bookmarks'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Bookmarks
              </button>
              <button
                onClick={() => setActiveTab('settings')}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'settings'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Settings
              </button>
            </nav>
          </div>
          
          <div className="mt-8">
            {renderTabContent()}
          </div>
        </div>
        
        {/* Recommended courses */}
        {myCourses.length > 0 && (
          <div className="mt-16">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Recommended For You</h2>
              <Link to="/courses" className="text-blue-600 hover:text-blue-700 flex items-center">
                View all <ChevronRight className="h-4 w-4 ml-1" />
              </Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {popularCourses
                .filter(course => !myCourses.some(c => c.id === course.id))
                .slice(0, 4)
                .map(course => (
                  <CourseCard key={course.id} course={course} />
                ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;