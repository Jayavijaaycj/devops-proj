import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { 
  Clock, 
  Users, 
  BarChart, 
  Award, 
  PlayCircle, 
  Check, 
  ChevronDown, 
  ChevronUp, 
  Star,
  Lock
} from 'lucide-react';
import Button from '../components/Button';
import { useCourses } from '../context/CourseContext';
import { useAuth } from '../context/AuthContext';

const CourseDetail: React.FC = () => {
  const { courseId } = useParams();
  const navigate = useNavigate();
  const { getCourse, enrollInCourse } = useCourses();
  const { isAuthenticated } = useAuth();
  const [isEnrolling, setIsEnrolling] = useState(false);
  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    curriculum: true,
    instructor: false,
  });
  
  // Get course details
  const course = getCourse(courseId || '');
  
  // Scroll to top on component mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  
  if (!course) {
    return (
      <div className="pt-20 min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Course Not Found</h2>
          <p className="text-gray-600 mb-6">The course you're looking for doesn't exist or has been removed.</p>
          <Link to="/courses">
            <Button variant="primary">Browse Courses</Button>
          </Link>
        </div>
      </div>
    );
  }
  
  const { 
    title, 
    description, 
    instructor, 
    thumbnail, 
    price, 
    rating, 
    totalStudents, 
    duration, 
    level, 
    lessons,
    enrolled,
    progress
  } = course;
  
  const toggleSection = (section: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };
  
  const handleEnroll = async () => {
    if (!isAuthenticated) {
      navigate('/login', { state: { redirectTo: `/courses/${courseId}` } });
      return;
    }
    
    try {
      setIsEnrolling(true);
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
      enrollInCourse(courseId || '');
    } catch (error) {
      console.error('Error enrolling in course:', error);
    } finally {
      setIsEnrolling(false);
    }
  };
  
  const continueLearning = () => {
    const firstIncompleteLesson = lessons.find(lesson => !lesson.completed);
    const lessonId = firstIncompleteLesson?.id || lessons[0].id;
    navigate(`/courses/${courseId}/lessons/${lessonId}`);
  };
  
  return (
    <div className="pt-16 min-h-screen bg-gray-50">
      {/* Hero section */}
      <section className="bg-gradient-to-r from-blue-900 to-purple-900 text-white py-16">
        <div className="container mx-auto px-4 md:px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold mb-6 leading-tight">
                {title}
              </h1>
              <p className="text-lg text-blue-100 mb-6">
                {description}
              </p>
              <div className="flex flex-wrap items-center gap-6 mb-8">
                <div className="flex items-center">
                  <Star className="h-5 w-5 text-yellow-400 fill-current" />
                  <span className="ml-2 font-medium">{rating.toFixed(1)}</span>
                </div>
                <div className="flex items-center">
                  <Users className="h-5 w-5 text-blue-200" />
                  <span className="ml-2">{totalStudents.toLocaleString()} students</span>
                </div>
                <div className="flex items-center">
                  <Clock className="h-5 w-5 text-blue-200" />
                  <span className="ml-2">{duration}</span>
                </div>
                <div className="flex items-center">
                  <BarChart className="h-5 w-5 text-blue-200" />
                  <span className="ml-2">{level}</span>
                </div>
              </div>
              <div className="flex items-center mb-6">
                <img 
                  src={instructor.avatar} 
                  alt={instructor.name} 
                  className="h-10 w-10 rounded-full mr-3" 
                />
                <div>
                  <p className="font-medium">Created by</p>
                  <p className="text-blue-200">{instructor.name}</p>
                </div>
              </div>
              
              {enrolled ? (
                <div>
                  <Button 
                    variant="primary" 
                    size="lg" 
                    onClick={continueLearning}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    {progress && progress > 0 ? 'Continue Learning' : 'Start Learning'}
                  </Button>
                  {progress !== undefined && progress > 0 && (
                    <div className="mt-4">
                      <div className="relative h-2 bg-blue-300 bg-opacity-30 rounded-full overflow-hidden">
                        <div 
                          className="absolute top-0 left-0 h-full bg-green-500"
                          style={{ width: `${progress}%` }}
                        ></div>
                      </div>
                      <p className="text-sm mt-1">{progress}% complete</p>
                    </div>
                  )}
                </div>
              ) : (
                <Button 
                  variant="primary" 
                  size="lg" 
                  onClick={handleEnroll}
                  isLoading={isEnrolling}
                >
                  Enroll Now - ${price.toFixed(2)}
                </Button>
              )}
            </div>
            <div className="relative hidden lg:block">
              <img 
                src={thumbnail} 
                alt={title} 
                className="w-full rounded-xl shadow-lg object-cover"
                style={{ maxHeight: '400px' }}
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-blue-600 bg-opacity-80 p-4 rounded-full">
                  <PlayCircle className="h-12 w-12 text-white" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      <div className="container mx-auto px-4 md:px-6 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main content */}
          <div className="lg:col-span-2">
            {/* Course overview */}
            <section className="bg-white rounded-lg shadow-md p-6 mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">What You'll Learn</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  "Master the fundamentals and advanced concepts",
                  "Build real-world projects for your portfolio",
                  "Learn industry best practices and techniques",
                  "Gain practical skills valuable in the workplace",
                  "Understand core principles and methodologies",
                  "Receive a certificate upon completion",
                  "Access to course updates and new content",
                  "Join our community of learners"
                ].map((item, index) => (
                  <div key={index} className="flex items-start">
                    <Check className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700">{item}</span>
                  </div>
                ))}
              </div>
            </section>
            
            {/* Course curriculum */}
            <section className="bg-white rounded-lg shadow-md p-6 mb-8">
              <div 
                className="flex justify-between items-center cursor-pointer"
                onClick={() => toggleSection('curriculum')}
              >
                <h2 className="text-2xl font-bold text-gray-900">Course Curriculum</h2>
                {expandedSections.curriculum ? (
                  <ChevronUp className="h-5 w-5 text-gray-600" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-gray-600" />
                )}
              </div>
              
              {expandedSections.curriculum && (
                <div className="mt-6">
                  <div className="text-sm text-gray-600 mb-4">
                    {lessons.length} lessons • {duration} total
                  </div>
                  
                  <div className="space-y-4">
                    {lessons.map((lesson, index) => (
                      <div key={lesson.id} className="border border-gray-200 rounded-lg overflow-hidden">
                        <div className="flex justify-between items-center p-4 bg-gray-50">
                          <div className="flex items-center">
                            <span className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center mr-3 font-medium">
                              {index + 1}
                            </span>
                            <h3 className="font-medium text-gray-900">{lesson.title}</h3>
                          </div>
                          <div className="flex items-center">
                            {lesson.completed ? (
                              <span className="bg-green-100 text-green-800 text-xs py-1 px-2 rounded-full mr-3">
                                Completed
                              </span>
                            ) : enrolled ? (
                              <PlayCircle className="h-5 w-5 text-blue-600 mr-3" />
                            ) : (
                              <Lock className="h-4 w-4 text-gray-500 mr-3" />
                            )}
                            <span className="text-sm text-gray-500">{lesson.duration}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </section>
            
            {/* Instructor */}
            <section className="bg-white rounded-lg shadow-md p-6">
              <div 
                className="flex justify-between items-center cursor-pointer"
                onClick={() => toggleSection('instructor')}
              >
                <h2 className="text-2xl font-bold text-gray-900">Your Instructor</h2>
                {expandedSections.instructor ? (
                  <ChevronUp className="h-5 w-5 text-gray-600" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-gray-600" />
                )}
              </div>
              
              {expandedSections.instructor && (
                <div className="mt-6">
                  <div className="flex items-start">
                    <img 
                      src={instructor.avatar} 
                      alt={instructor.name} 
                      className="h-16 w-16 rounded-full mr-4 object-cover" 
                    />
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">{instructor.name}</h3>
                      <p className="text-gray-600 mb-4">{instructor.bio}</p>
                      <div className="flex flex-wrap gap-4">
                        <div>
                          <p className="font-medium text-gray-900">4.8</p>
                          <p className="text-sm text-gray-600">Instructor Rating</p>
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">28,492</p>
                          <p className="text-sm text-gray-600">Students</p>
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">12</p>
                          <p className="text-sm text-gray-600">Courses</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </section>
          </div>
          
          {/* Sidebar */}
          <div>
            {/* Mobile course preview */}
            <div className="lg:hidden relative mb-8">
              <img 
                src={thumbnail} 
                alt={title} 
                className="w-full rounded-xl shadow-lg object-cover"
                style={{ maxHeight: '300px' }}
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="bg-blue-600 bg-opacity-80 p-4 rounded-full">
                  <PlayCircle className="h-12 w-12 text-white" />
                </div>
              </div>
            </div>
            
            {/* Course info card */}
            <div className="bg-white rounded-lg shadow-md overflow-hidden sticky top-24">
              {!enrolled && (
                <div className="p-6">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-2xl font-bold text-gray-900">${price.toFixed(2)}</h3>
                    <div className="bg-red-100 text-red-800 text-sm px-2 py-1 rounded-md">
                      40% off
                    </div>
                  </div>
                  <Button 
                    variant="primary" 
                    size="lg" 
                    fullWidth 
                    onClick={handleEnroll}
                    isLoading={isEnrolling}
                  >
                    Enroll Now
                  </Button>
                  <p className="text-center text-sm text-gray-500 mt-3">
                    30-Day Money-Back Guarantee
                  </p>
                </div>
              )}
              
              <div className="border-t border-gray-200 p-6">
                <h3 className="font-bold text-gray-900 mb-4">This Course Includes:</h3>
                <ul className="space-y-3">
                  <li className="flex items-center text-gray-700">
                    <PlayCircle className="h-5 w-5 text-gray-500 mr-3" />
                    {lessons.length} on-demand lessons
                  </li>
                  <li className="flex items-center text-gray-700">
                    <Clock className="h-5 w-5 text-gray-500 mr-3" />
                    Full lifetime access
                  </li>
                  <li className="flex items-center text-gray-700">
                    <Award className="h-5 w-5 text-gray-500 mr-3" />
                    Certificate of completion
                  </li>
                  <li className="flex items-center text-gray-700">
                    <Users className="h-5 w-5 text-gray-500 mr-3" />
                    Community support
                  </li>
                </ul>
              </div>
              
              {enrolled && (
                <div className="border-t border-gray-200 p-6">
                  <Button 
                    variant="primary" 
                    size="lg" 
                    fullWidth 
                    onClick={continueLearning}
                  >
                    {progress && progress > 0 ? 'Continue Learning' : 'Start Course'}
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CourseDetail;