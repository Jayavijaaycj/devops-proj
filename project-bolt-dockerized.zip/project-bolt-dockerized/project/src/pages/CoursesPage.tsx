import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Filter, X } from 'lucide-react';
import SearchBar from '../components/SearchBar';
import CourseCard from '../components/CourseCard';
import Button from '../components/Button';
import { useCourses } from '../context/CourseContext';

const CoursesPage: React.FC = () => {
  const { courses, categories, searchCourses, filterCoursesByCategory } = useCourses();
  const [searchParams, setSearchParams] = useSearchParams();
  const [filteredCourses, setFilteredCourses] = useState(courses);
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  
  const initialCategory = searchParams.get('category') || 'all';
  const initialSearch = searchParams.get('search') || '';
  
  const [selectedCategory, setSelectedCategory] = useState(initialCategory);
  const [searchQuery, setSearchQuery] = useState(initialSearch);
  const [selectedLevel, setSelectedLevel] = useState<string>('all');
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 100]);
  
  // Scroll to top on component mount
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  
  // Apply filters
  useEffect(() => {
    let results = courses;
    
    // Apply search filter
    if (searchQuery) {
      results = searchCourses(searchQuery);
    }
    
    // Apply category filter
    if (selectedCategory !== 'all') {
      results = filterCoursesByCategory(selectedCategory);
    }
    
    // Apply level filter
    if (selectedLevel !== 'all') {
      results = results.filter(course => course.level.toLowerCase() === selectedLevel.toLowerCase());
    }
    
    // Apply price filter
    results = results.filter(course => 
      course.price >= priceRange[0] && course.price <= priceRange[1] * 10
    );
    
    setFilteredCourses(results);
    
    // Update URL params
    const params: Record<string, string> = {};
    if (searchQuery) params.search = searchQuery;
    if (selectedCategory !== 'all') params.category = selectedCategory;
    
    setSearchParams(params);
  }, [searchQuery, selectedCategory, selectedLevel, priceRange, courses]);
  
  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };
  
  const resetFilters = () => {
    setSelectedCategory('all');
    setSelectedLevel('all');
    setPriceRange([0, 100]);
    setSearchQuery('');
    setSearchParams({});
  };
  
  const toggleFilters = () => {
    setIsFilterOpen(!isFilterOpen);
  };
  
  return (
    <div className="pt-16 min-h-screen bg-gray-50">
      {/* Header */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4 md:px-6">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Explore Our Courses
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl">
            Discover the perfect course to enhance your skills and advance your career with our comprehensive selection.
          </p>
          <div className="max-w-xl mt-8">
            <SearchBar onSearch={handleSearch} placeholder="Search courses..." />
          </div>
        </div>
      </section>
      
      <div className="container mx-auto px-4 md:px-6 py-12">
        {/* Mobile filter toggle */}
        <div className="md:hidden mb-6">
          <Button 
            variant="outline" 
            onClick={toggleFilters}
            className="flex items-center gap-2"
          >
            <Filter className="h-4 w-4" />
            {isFilterOpen ? 'Hide Filters' : 'Show Filters'}
          </Button>
        </div>
        
        <div className="flex flex-col md:flex-row gap-8">
          {/* Filter sidebar */}
          <div className={`${isFilterOpen ? 'block' : 'hidden'} md:block w-full md:w-1/4 lg:w-1/5`}>
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold text-gray-900">Filters</h2>
                <button 
                  onClick={resetFilters}
                  className="text-sm text-blue-600 hover:text-blue-700"
                >
                  Reset All
                </button>
              </div>
              
              {/* Categories filter */}
              <div className="mb-8">
                <h3 className="text-gray-900 font-medium mb-3">Categories</h3>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <input
                      type="radio"
                      id="category-all"
                      name="category"
                      checked={selectedCategory === 'all'}
                      onChange={() => setSelectedCategory('all')}
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500"
                    />
                    <label htmlFor="category-all" className="ml-2 text-gray-700">
                      All Categories
                    </label>
                  </div>
                  
                  {categories.map(category => (
                    <div key={category.id} className="flex items-center">
                      <input
                        type="radio"
                        id={`category-${category.id}`}
                        name="category"
                        checked={selectedCategory === category.id}
                        onChange={() => setSelectedCategory(category.id)}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500"
                      />
                      <label htmlFor={`category-${category.id}`} className="ml-2 text-gray-700">
                        {category.name}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Level filter */}
              <div className="mb-8">
                <h3 className="text-gray-900 font-medium mb-3">Level</h3>
                <div className="space-y-2">
                  <div className="flex items-center">
                    <input
                      type="radio"
                      id="level-all"
                      name="level"
                      checked={selectedLevel === 'all'}
                      onChange={() => setSelectedLevel('all')}
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500"
                    />
                    <label htmlFor="level-all" className="ml-2 text-gray-700">
                      All Levels
                    </label>
                  </div>
                  {['Beginner', 'Intermediate', 'Advanced'].map(level => (
                    <div key={level} className="flex items-center">
                      <input
                        type="radio"
                        id={`level-${level.toLowerCase()}`}
                        name="level"
                        checked={selectedLevel === level.toLowerCase()}
                        onChange={() => setSelectedLevel(level.toLowerCase())}
                        className="h-4 w-4 text-blue-600 focus:ring-blue-500"
                      />
                      <label htmlFor={`level-${level.toLowerCase()}`} className="ml-2 text-gray-700">
                        {level}
                      </label>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Price filter */}
              <div>
                <h3 className="text-gray-900 font-medium mb-3">Price Range</h3>
                <div className="px-2">
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={priceRange[1]}
                    onChange={(e) => setPriceRange([0, parseInt(e.target.value)])}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                  />
                  <div className="flex justify-between mt-2 text-sm text-gray-600">
                    <span>${priceRange[0]}</span>
                    <span>Up to ${priceRange[1] * 10}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Course list */}
          <div className="w-full md:w-3/4 lg:w-4/5">
            <div className="mb-6 flex justify-between items-center">
              <h2 className="text-xl font-semibold text-gray-900">
                {filteredCourses.length} {filteredCourses.length === 1 ? 'Course' : 'Courses'} 
                {searchQuery && <span> for "{searchQuery}"</span>}
              </h2>
              <div className="flex items-center space-x-2">
                {(searchQuery || selectedCategory !== 'all' || selectedLevel !== 'all' || priceRange[1] < 100) && (
                  <div className="bg-gray-100 px-3 py-1 rounded-full flex items-center text-gray-600 text-sm">
                    <span>Filters Applied</span>
                    <button 
                      onClick={resetFilters}
                      className="ml-2 p-1 rounded-full hover:bg-gray-200"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                )}
              </div>
            </div>
            
            {filteredCourses.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredCourses.map(course => (
                  <CourseCard key={course.id} course={course} />
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-lg shadow-md p-8 text-center">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">No Courses Found</h3>
                <p className="text-gray-600 mb-6">
                  We couldn't find any courses matching your current filters.
                </p>
                <Button variant="outline" onClick={resetFilters}>
                  Reset Filters
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CoursesPage;