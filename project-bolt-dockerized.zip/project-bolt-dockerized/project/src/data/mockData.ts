import { Course, Category } from '../context/CourseContext';

export const mockCourses: Course[] = [
  {
    id: 'course-1',
    title: 'Introduction to Web Development',
    description: 'Learn the fundamentals of web development, including HTML, CSS, and JavaScript. This course is perfect for beginners with no prior coding experience.',
    instructor: {
      id: 'instructor-1',
      name: 'Sarah Johnson',
      avatar: 'https://i.pravatar.cc/150?img=32',
      bio: 'Senior Web Developer with 10+ years of experience teaching coding fundamentals to beginners.'
    },
    thumbnail: 'https://images.pexels.com/photos/1181263/pexels-photo-1181263.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    price: 49.99,
    rating: 4.8,
    totalStudents: 12458,
    duration: '6 weeks',
    level: 'Beginner',
    category: 'web-development',
    tags: ['HTML', 'CSS', 'JavaScript', 'Web Development'],
    lessons: [
      { id: 'lesson-1-1', title: 'HTML Basics', duration: '45 min' },
      { id: 'lesson-1-2', title: 'CSS Fundamentals', duration: '50 min' },
      { id: 'lesson-1-3', title: 'JavaScript Introduction', duration: '55 min' },
      { id: 'lesson-1-4', title: 'Building Your First Webpage', duration: '60 min' },
      { id: 'lesson-1-5', title: 'Web Accessibility', duration: '40 min' },
      { id: 'lesson-1-6', title: 'Responsive Design', duration: '50 min' }
    ]
  },
  {
    id: 'course-2',
    title: 'Data Science Fundamentals',
    description: 'Master the essential skills for data analysis and visualization. Learn Python, pandas, and matplotlib to extract insights from real-world datasets.',
    instructor: {
      id: 'instructor-2',
      name: 'Dr. Michael Chen',
      avatar: 'https://i.pravatar.cc/150?img=11',
      bio: 'Data Scientist with a PhD in Computer Science and experience at leading tech companies.'
    },
    thumbnail: 'https://images.pexels.com/photos/669615/pexels-photo-669615.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    price: 69.99,
    rating: 4.7,
    totalStudents: 8932,
    duration: '8 weeks',
    level: 'Intermediate',
    category: 'data-science',
    tags: ['Python', 'Data Analysis', 'Statistics', 'Machine Learning'],
    lessons: [
      { id: 'lesson-2-1', title: 'Python for Data Science', duration: '60 min' },
      { id: 'lesson-2-2', title: 'Data Manipulation with Pandas', duration: '65 min' },
      { id: 'lesson-2-3', title: 'Data Visualization', duration: '55 min' },
      { id: 'lesson-2-4', title: 'Statistical Analysis', duration: '70 min' },
      { id: 'lesson-2-5', title: 'Introduction to Machine Learning', duration: '75 min' }
    ]
  },
  {
    id: 'course-3',
    title: 'UX/UI Design Principles',
    description: 'Learn the principles of user experience and interface design. Create beautiful, intuitive designs that users will love.',
    instructor: {
      id: 'instructor-3',
      name: 'Emma Rodriguez',
      avatar: 'https://i.pravatar.cc/150?img=23',
      bio: 'Award-winning UX designer with expertise in creating user-centered digital experiences.'
    },
    thumbnail: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    price: 59.99,
    rating: 4.9,
    totalStudents: 7345,
    duration: '5 weeks',
    level: 'Beginner',
    category: 'design',
    tags: ['UI', 'UX', 'Design', 'Prototyping'],
    lessons: [
      { id: 'lesson-3-1', title: 'Introduction to UX Design', duration: '40 min' },
      { id: 'lesson-3-2', title: 'User Research Methods', duration: '55 min' },
      { id: 'lesson-3-3', title: 'Wireframing and Prototyping', duration: '60 min' },
      { id: 'lesson-3-4', title: 'UI Design Fundamentals', duration: '50 min' },
      { id: 'lesson-3-5', title: 'Design Systems', duration: '45 min' },
      { id: 'lesson-3-6', title: 'Usability Testing', duration: '50 min' }
    ],
    enrolled: true,
    progress: 50
  },
  {
    id: 'course-4',
    title: 'Mobile App Development with React Native',
    description: 'Build cross-platform mobile applications using React Native. Learn once, write anywhere with this powerful framework.',
    instructor: {
      id: 'instructor-4',
      name: 'James Wilson',
      avatar: 'https://i.pravatar.cc/150?img=8',
      bio: 'Mobile developer with expertise in React Native and native app development for iOS and Android.'
    },
    thumbnail: 'https://images.pexels.com/photos/147413/twitter-facebook-together-exchange-of-information-147413.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    price: 79.99,
    rating: 4.6,
    totalStudents: 6298,
    duration: '8 weeks',
    level: 'Intermediate',
    category: 'mobile-development',
    tags: ['React Native', 'Mobile', 'iOS', 'Android'],
    lessons: [
      { id: 'lesson-4-1', title: 'React Native Basics', duration: '55 min' },
      { id: 'lesson-4-2', title: 'Building UI Components', duration: '60 min' },
      { id: 'lesson-4-3', title: 'Navigation in React Native', duration: '50 min' },
      { id: 'lesson-4-4', title: 'State Management', duration: '65 min' },
      { id: 'lesson-4-5', title: 'Using Native APIs', duration: '70 min' },
      { id: 'lesson-4-6', title: 'Publishing Your App', duration: '45 min' }
    ]
  },
  {
    id: 'course-5',
    title: 'Advanced JavaScript Concepts',
    description: 'Dive deep into advanced JavaScript concepts including closures, prototypes, async programming, and modern ES6+ features.',
    instructor: {
      id: 'instructor-5',
      name: 'David Kumar',
      avatar: 'https://i.pravatar.cc/150?img=67',
      bio: 'JavaScript expert and open source contributor with a passion for teaching complex concepts simply.'
    },
    thumbnail: 'https://images.pexels.com/photos/270348/pexels-photo-270348.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    price: 89.99,
    rating: 4.9,
    totalStudents: 5467,
    duration: '6 weeks',
    level: 'Advanced',
    category: 'web-development',
    tags: ['JavaScript', 'ES6', 'Async', 'Performance'],
    lessons: [
      { id: 'lesson-5-1', title: 'JavaScript Execution Context', duration: '60 min' },
      { id: 'lesson-5-2', title: 'Closures and Scopes', duration: '55 min' },
      { id: 'lesson-5-3', title: 'Prototypal Inheritance', duration: '65 min' },
      { id: 'lesson-5-4', title: 'Async Programming', duration: '70 min' },
      { id: 'lesson-5-5', title: 'Modern JavaScript Features', duration: '60 min' },
      { id: 'lesson-5-6', title: 'Performance Optimization', duration: '50 min' }
    ],
    enrolled: true,
    progress: 30
  },
  {
    id: 'course-6',
    title: 'Blockchain Development',
    description: 'Learn the fundamentals of blockchain technology and how to build decentralized applications using Ethereum and Solidity.',
    instructor: {
      id: 'instructor-6',
      name: 'Alex Nakamoto',
      avatar: 'https://i.pravatar.cc/150?img=14',
      bio: 'Blockchain developer and educator specializing in Ethereum and smart contract development.'
    },
    thumbnail: 'https://images.pexels.com/photos/844124/pexels-photo-844124.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    price: 99.99,
    rating: 4.7,
    totalStudents: 3289,
    duration: '10 weeks',
    level: 'Advanced',
    category: 'blockchain',
    tags: ['Blockchain', 'Ethereum', 'Solidity', 'Smart Contracts'],
    lessons: [
      { id: 'lesson-6-1', title: 'Introduction to Blockchain', duration: '50 min' },
      { id: 'lesson-6-2', title: 'Ethereum Basics', duration: '60 min' },
      { id: 'lesson-6-3', title: 'Smart Contract Development', duration: '75 min' },
      { id: 'lesson-6-4', title: 'Web3.js Integration', duration: '65 min' },
      { id: 'lesson-6-5', title: 'Building a DApp', duration: '80 min' },
      { id: 'lesson-6-6', title: 'Security Best Practices', duration: '55 min' }
    ]
  }
];

export const mockCategories: Category[] = [
  {
    id: 'web-development',
    name: 'Web Development',
    icon: 'Code',
    courses: 42
  },
  {
    id: 'data-science',
    name: 'Data Science',
    icon: 'BarChart',
    courses: 35
  },
  {
    id: 'design',
    name: 'Design',
    icon: 'Palette',
    courses: 28
  },
  {
    id: 'mobile-development',
    name: 'Mobile Development',
    icon: 'Smartphone',
    courses: 24
  },
  {
    id: 'blockchain',
    name: 'Blockchain',
    icon: 'Link',
    courses: 18
  },
  {
    id: 'business',
    name: 'Business',
    icon: 'Briefcase',
    courses: 31
  },
  {
    id: 'marketing',
    name: 'Marketing',
    icon: 'TrendingUp',
    courses: 26
  },
  {
    id: 'photography',
    name: 'Photography',
    icon: 'Camera',
    courses: 22
  }
];