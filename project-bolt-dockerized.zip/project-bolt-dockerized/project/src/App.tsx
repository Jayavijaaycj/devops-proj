import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import CoursesPage from './pages/CoursesPage';
import CourseDetail from './pages/CourseDetail';
import Dashboard from './pages/Dashboard';
import LessonViewer from './pages/LessonViewer';
import Login from './pages/Login';
import Signup from './pages/Signup';
import { AuthProvider } from './context/AuthContext';
import { CourseProvider } from './context/CourseContext';

function App() {
  return (
    <Router>
      <AuthProvider>
        <CourseProvider>
          <div className="flex flex-col min-h-screen">
            <Navbar />
            <main className="flex-grow">
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/courses" element={<CoursesPage />} />
                <Route path="/courses/:courseId" element={<CourseDetail />} />
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/courses/:courseId/lessons/:lessonId" element={<LessonViewer />} />
                <Route path="/login" element={<Login />} />
                <Route path="/signup" element={<Signup />} />
              </Routes>
            </main>
            <Footer />
          </div>
        </CourseProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;