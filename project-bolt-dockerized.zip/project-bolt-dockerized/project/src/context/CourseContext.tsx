import React, { createContext, useState, useContext } from 'react';
import { mockCourses, mockCategories } from '../data/mockData';

// Types
export type Course = {
  id: string;
  title: string;
  description: string;
  instructor: {
    id: string;
    name: string;
    avatar: string;
    bio: string;
  };
  thumbnail: string;
  price: number;
  rating: number;
  totalStudents: number;
  duration: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  category: string;
  tags: string[];
  lessons: {
    id: string;
    title: string;
    duration: string;
    completed?: boolean;
    videoUrl?: string;
  }[];
  enrolled?: boolean;
  progress?: number;
};

export type Category = {
  id: string;
  name: string;
  icon: string;
  courses: number;
};

type CourseContextType = {
  courses: Course[];
  categories: Category[];
  featuredCourses: Course[];
  popularCourses: Course[];
  myCourses: Course[];
  getCourse: (id: string) => Course | undefined;
  searchCourses: (query: string) => Course[];
  filterCoursesByCategory: (categoryId: string) => Course[];
  enrollInCourse: (courseId: string) => void;
  markLessonComplete: (courseId: string, lessonId: string) => void;
};

// Create context
const CourseContext = createContext<CourseContextType | undefined>(undefined);

export const CourseProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [courses, setCourses] = useState<Course[]>(mockCourses);
  const [categories] = useState<Category[]>(mockCategories);
  
  const featuredCourses = courses.slice(0, 3);
  const popularCourses = [...courses].sort((a, b) => b.totalStudents - a.totalStudents).slice(0, 4);
  const myCourses = courses.filter(course => course.enrolled);
  
  const getCourse = (id: string) => {
    return courses.find(course => course.id === id);
  };
  
  const searchCourses = (query: string) => {
    if (!query) return courses;
    
    const lowercaseQuery = query.toLowerCase();
    return courses.filter(course => 
      course.title.toLowerCase().includes(lowercaseQuery) || 
      course.description.toLowerCase().includes(lowercaseQuery) ||
      course.tags.some(tag => tag.toLowerCase().includes(lowercaseQuery))
    );
  };
  
  const filterCoursesByCategory = (categoryId: string) => {
    if (!categoryId || categoryId === 'all') return courses;
    return courses.filter(course => course.category === categoryId);
  };
  
  const enrollInCourse = (courseId: string) => {
    setCourses(prevCourses => 
      prevCourses.map(course => 
        course.id === courseId 
          ? { ...course, enrolled: true, progress: 0 } 
          : course
      )
    );
  };
  
  const markLessonComplete = (courseId: string, lessonId: string) => {
    setCourses(prevCourses => 
      prevCourses.map(course => {
        if (course.id !== courseId) return course;
        
        const updatedLessons = course.lessons.map(lesson => 
          lesson.id === lessonId ? { ...lesson, completed: true } : lesson
        );
        
        const completedLessons = updatedLessons.filter(lesson => lesson.completed).length;
        const progress = Math.round((completedLessons / updatedLessons.length) * 100);
        
        return {
          ...course,
          lessons: updatedLessons,
          progress
        };
      })
    );
  };
  
  return (
    <CourseContext.Provider 
      value={{ 
        courses,
        categories,
        featuredCourses,
        popularCourses,
        myCourses,
        getCourse,
        searchCourses,
        filterCoursesByCategory,
        enrollInCourse,
        markLessonComplete
      }}
    >
      {children}
    </CourseContext.Provider>
  );
};

export const useCourses = () => {
  const context = useContext(CourseContext);
  if (context === undefined) {
    throw new Error('useCourses must be used within a CourseProvider');
  }
  return context;
};