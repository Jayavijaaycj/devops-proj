import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, Users, Star } from 'lucide-react';
import { Course } from '../context/CourseContext';

interface CourseCardProps {
  course: Course;
  variant?: 'default' | 'compact';
}

const CourseCard: React.FC<CourseCardProps> = ({ course, variant = 'default' }) => {
  const { 
    id, 
    title, 
    instructor, 
    thumbnail, 
    rating, 
    totalStudents, 
    duration, 
    level, 
    price,
    progress
  } = course;
  
  if (variant === 'compact') {
    return (
      <Link to={`/courses/${id}`} className="flex group bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow duration-300">
        <div className="w-1/3 relative">
          <img 
            src={thumbnail} 
            alt={title} 
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
          {progress !== undefined && (
            <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-70 px-2 py-1">
              <div className="relative h-1.5 bg-gray-300 rounded-full overflow-hidden">
                <div 
                  className="absolute top-0 left-0 h-full bg-green-500" 
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
              <p className="text-xs text-white text-right mt-1">{progress}% complete</p>
            </div>
          )}
        </div>
        <div className="w-2/3 p-4">
          <h3 className="text-lg font-semibold text-gray-900 line-clamp-1">{title}</h3>
          <p className="text-sm text-gray-600 mb-2">{instructor.name}</p>
          <div className="flex items-center text-sm text-gray-500">
            <Clock className="h-4 w-4 mr-1" />
            <span>{duration}</span>
            <span className="mx-2">•</span>
            <span className={`px-2 py-0.5 text-xs rounded-full ${
              level === 'Beginner' ? 'bg-green-100 text-green-800' :
              level === 'Intermediate' ? 'bg-yellow-100 text-yellow-800' :
              'bg-red-100 text-red-800'
            }`}>{level}</span>
          </div>
        </div>
      </Link>
    );
  }
  
  return (
    <Link to={`/courses/${id}`} className="group bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow duration-300">
      <div className="relative overflow-hidden">
        <img 
          src={thumbnail} 
          alt={title} 
          className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-105"
        />
        {progress !== undefined && (
          <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-70 px-3 py-2">
            <div className="relative h-2 bg-gray-300 rounded-full overflow-hidden">
              <div 
                className="absolute top-0 left-0 h-full bg-green-500" 
                style={{ width: `${progress}%` }}
              ></div>
            </div>
            <p className="text-xs text-white text-right mt-1">{progress}% complete</p>
          </div>
        )}
        <div className="absolute top-3 right-3 bg-blue-600 text-white px-2 py-1 rounded-md text-sm font-medium">
          ${price.toFixed(2)}
        </div>
      </div>
      <div className="p-5">
        <h3 className="text-xl font-semibold text-gray-900 mb-2 line-clamp-2">{title}</h3>
        <p className="text-gray-600 mb-4">{instructor.name}</p>
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center text-yellow-500">
            <Star className="h-4 w-4 fill-current" />
            <span className="ml-1 text-gray-700">{rating.toFixed(1)}</span>
          </div>
          <div className="flex items-center text-gray-500">
            <Users className="h-4 w-4 mr-1" />
            <span>{totalStudents.toLocaleString()} students</span>
          </div>
        </div>
        <div className="flex items-center mt-3 text-gray-500 text-sm">
          <Clock className="h-4 w-4 mr-1" />
          <span>{duration}</span>
          <span className="mx-2">•</span>
          <span className={`px-2 py-0.5 text-xs rounded-full ${
            level === 'Beginner' ? 'bg-green-100 text-green-800' :
            level === 'Intermediate' ? 'bg-yellow-100 text-yellow-800' :
            'bg-red-100 text-red-800'
          }`}>{level}</span>
        </div>
      </div>
    </Link>
  );
};

export default CourseCard;