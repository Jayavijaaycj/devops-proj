import React from 'react';
import { Link } from 'react-router-dom';
import * as Icons from 'lucide-react';
import { Category } from '../context/CourseContext';

interface CategoryCardProps {
  category: Category;
}

const CategoryCard: React.FC<CategoryCardProps> = ({ category }) => {
  const { id, name, icon, courses } = category;
  
  // Dynamically get the icon component
  const IconComponent = Icons[icon as keyof typeof Icons];
  
  return (
    <Link 
      to={`/courses?category=${id}`} 
      className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow flex flex-col items-center text-center"
    >
      <div className="bg-blue-100 p-4 rounded-full mb-4">
        {IconComponent && <IconComponent className="h-8 w-8 text-blue-600" />}
      </div>
      <h3 className="text-lg font-semibold text-gray-900 mb-1">{name}</h3>
      <p className="text-sm text-gray-500">{courses} courses</p>
    </Link>
  );
};

export default CategoryCard;